import time, cv2, serial, logging
import numpy as np
from logging import info, error
from coloredlogs import install 

log_format = "%(asctime)s - %(hostname)s:%(username)s:%(programname)s - %(levelname)s: %(message)s"
install(level="info", format=log_format)
logging.basicConfig(level=logging.INFO)
# ======== CONFIGURABLE OFFSETS =========
y_fix = 30 #################################
X_OFFSET = 4.8  # ลดค่า X ลง 4.8 mm                                               #X_OFFSET = ______
Y_OFFSET = 120-y_fix   # เพิ่มค่า Y ขึ้น 120 mm                                       #Y_OFFSET = ______
# =======================================

########################################################################
def init_serial():
    return serial.Serial(port="COM3", baudrate=115200)                           #port="COM____"

def send_state(serial_port, data):
    try:
        serial_port.write(f"{data}\n".encode('utf-8'))
        time.sleep(0.5)
        info(f"Sent: {data}")
    except serial.SerialException as e:
        error(f"Error Sending data: {e}")

def receive_state(serial_port):
    state_message = ["Sethome position", "Ready to detect", "Sucess to pick objects"]
    try:
        while True:
            if serial_port.in_waiting > 0:
                line = serial_port.readline().decode('utf-8').rstrip()
                info(f"Receive: {line}")
                if line in state_message:
                    break
    except serial.SerialException as e:
        error(f"Serial communication error: {e}")
    except KeyboardInterrupt:
        error("Stopped by user.")

########################################################################
def object_position_check(data_stream, stamp_choose, target_count=50):    #ถ้าอยากให้ detect นานขึ้นให้เพิ่ม Target_count = __________
    count, last_value = 0, None
    for data in data_stream:
        if data == last_value:
            count += 1
        else:
            count = 1
            last_value = data
        if count == target_count:
            # ปรับค่าตำแหน่งตาม offset
            adjusted_x = data[0] + X_OFFSET
            adjusted_y = data[1] + Y_OFFSET
            return f"G{stamp_choose} X{adjusted_x:.1f} Y{adjusted_y:.1f}"
    return None 

def object_position_cal(frame, cx, cy, mm_per_pixel = 0.53):              #mm_per_pixel = _____
    h, w, c_channel = frame.shape
    cam_center = (int(w / 2), int(h / 2))
    offset_x = cx - cam_center[0]
    offset_y = cy - cam_center[1]
    cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
    cv2.line(frame, cam_center, (cx, cy), (255, 255, 255), 2)

    return int(offset_x * mm_per_pixel), int(offset_y * mm_per_pixel)

def color_detection_choose(c_choose, frame):
    frame_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    if c_choose == "red":
        lower_red1 = np.array([0, 100, 100])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 100, 100])
        upper_red2 = np.array([179, 255, 255])
        mask1 = cv2.inRange(frame_hsv, lower_red1, upper_red1)
        mask2 = cv2.inRange(frame_hsv, lower_red2, upper_red2)
        mask = mask1 + mask2
        return mask
    elif c_choose == "b":
       lower_lightblue = np.array([94.31, 45.24, 134.35])
       upper_lightblue = np.array([158.8, 255, 255])
       mask_lightblue = cv2.inRange(frame_hsv, lower_lightblue, upper_lightblue)
       return mask_lightblue
    #============================================================================#
    # elif c_choose == "____":
    #    lower_.... = np.array([___,___,___])
    #    upper_.... = np.array([___,___,___])
    #    mask_.... = cv2.inRange(frame_hsv, lower_....., upper_.....)
    #    return mask_....


    #============================================================================#

    else:
        return None

def camera_shape_detection(c_choose):
    cap = cv2.VideoCapture(1)     #cv2.VideoCapture(0) คือใช้กล้องตัวที่ 0 , cv2.VideoCapture(1) คือใช้กล้องตัวที่ 1
    info("SHAPE DETECTION IS PROCESSING..")
    data_list = []
    try:
        while True:
            try:
                ret ,frame = cap.read()
                if not ret:
                    error("Failed to read from camera.")
                    break
                mask_c = color_detection_choose(c_choose=c_choose, frame=frame)
                contours, _ = cv2.findContours(mask_c, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                if contours:
                    c = max(contours, key=cv2.contourArea)
                    M = cv2.moments(c)

                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])
                        data = object_position_cal(frame=frame, cx=cx, cy=cy)
                        data_list.append(data)                  
                        offset_x_mm = data[0]
                        offset_y_mm = data[1]
                        cv2.putText(frame, f"Offset: ({offset_x_mm:.1f} mm, {offset_y_mm:.1f} mm)", 
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                        object_result = object_position_check(data_stream=data_list, stamp_choose=1)
                        if object_result:
                            return str(object_result)
                cv2.imshow("OPEN-SHAPE DETECTION", frame)
                if cv2.waitKey(1) == ord('q'):       #กด q เพื่อ stop
                    info("Closed Camera by user")
                    break

            except Exception as e:
                error(f"Error during frame processing: {e}")
    except Exception as e:
        error(f"Critical error: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()

########################################################################
def process_setup():
    try:
        ser = init_serial()
        if ser.is_open:
            info("SERIAL PORT IS OPEN AND CONFIGURED.")
            time.sleep(2)
            send_state(serial_port=ser, data="home")
            receive_state(serial_port=ser)

            time.sleep(2)
            send_state(serial_port=ser, data="ready")
            receive_state(serial_port=ser)
            time.sleep(2)
            info("SETUP PROCESS COMPLETELY.")
            return ser
    except serial.SerialException as e:
        error(f"Serial communication error: {e}")
        return None

def main(input):
    ser = None
    try:
        ser = process_setup()
        shape_coor = camera_shape_detection(c_choose=input)
        if shape_coor:
            info(f"SENT COORDINATE '{shape_coor}' TO CARTESIAN.")
            time.sleep(2)
            send_state(serial_port=ser, data=shape_coor)
            receive_state(serial_port=ser)
            info("SHAPE DETECTION IS END PROCESS")
        else:
            info("CANNOT SENT COORDINATE TO CARTESIAN, END PROCESS.")
    except Exception as e:
        error(f"Main function error : {e}")
    finally:
        if ser and ser.is_open:
            ser.close()

if __name__ == '__main__':
    c_choose = input("[INPUT] CHOOSE COLOR WHAT TO DETECT (r:red, b:blue, g:green, o:orange): ").strip().lower() #(r:red, b:blue, g:green, o:orange, _____________):
    main(c_choose)

   #---------- Check state of cartesian-------------------------#
    # ser = init_serial()
    # input_car = input("SENT STAGE CARTESIAN: ").strip().lower()
    # send_state(serial_port=ser, data=input_car)
    #-------------------------------------------------------------#