import cv2
import numpy as np

# เปิดกล้อง
cap = cv2.VideoCapture(1)  # หรือใส่ index ของกล้องที่คุณใช้งาน

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # แปลงภาพจาก BGR เป็น HSV
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # กำหนดช่วงของสีแดงใน HSV (อาจต้องปรับตาม lighting จริง)
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([179, 255, 255])

    # สร้าง mask สำหรับสีแดง
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask = mask1 + mask2

    # หาคอนทัวร์ของวัตถุ
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    height, width, _ = frame.shape ### (480 X 640) #####
    cam_center = (int(width / 2), int(height / 2))

    ###############################################################################

    if contours:
        c = max(contours, key=cv2.contourArea)
        M = cv2.moments(c)

        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            offset_x = cx - cam_center[0]
            offset_y = cy - cam_center[1]

            mm_per_pixel = 0.26356589147
            offset_x_mm = offset_x * mm_per_pixel
            offset_y_mm = offset_y * mm_per_pixel

            cv2.circle(frame, (cx, cy), 5, (0, 255, 0), -1)
            cv2.line(frame, cam_center, (cx, cy), (255, 255, 255), 2)

            cv2.putText(frame, f"offset: ({offset_x_mm:.1f} mm, {offset_y_mm:.1f} mm)",
                        (10, 30), cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 255, 255), 2)   
            cv2.putText(frame, f"offset: ({offset_x:.1f} pixel, {offset_y:.1f} pixel)",
                        (10, 100), cv2.FONT_HERSHEY_COMPLEX, 0.7, (0, 255, 255), 2)           

    ################################################################################

       # แสดงกล้อง
    cv2.imshow("Camera", frame)
    cv2.imshow("Mask", mask)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
